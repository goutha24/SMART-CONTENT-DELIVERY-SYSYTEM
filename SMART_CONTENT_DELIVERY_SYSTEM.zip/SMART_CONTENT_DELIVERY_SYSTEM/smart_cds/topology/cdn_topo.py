#!/usr/bin/env python3
"""
Mininet topology for Smart Content Delivery System.

Topology (simple but realistic for demo):

          c1 ---- s1 ---- s2 ---- s3
                   |      |      |
                  srv1   srv2   srv3
                   |             |
                  c2            c3

- 3 content servers (srv1, srv2, srv3) on different switches
- Multiple clients
- Core switches form a small mesh so SDN can do alternate paths
- Links have different bandwidths / delays to create interesting conditions

Clients request content from a virtual IP (10.0.0.100) that the SDN controller
rewrites / redirects toward the currently best server.
"""

from mininet.topo import Topo
from mininet.net import Mininet
from mininet.node import RemoteController, OVSSwitch, Host
from mininet.link import TCLink
from mininet.cli import CLI
from mininet.log import setLogLevel, info
import argparse


class SmartCDNTopo(Topo):
    def build(self):
        # Switches
        s1 = self.addSwitch("s1", dpid="0000000000000001")
        s2 = self.addSwitch("s2", dpid="0000000000000002")
        s3 = self.addSwitch("s3", dpid="0000000000000003")
        s4 = self.addSwitch("s4", dpid="0000000000000004")  # core / aggregation

        # Content servers
        srv1 = self.addHost("srv1", ip="10.0.0.11/24", mac="00:00:00:00:00:11")
        srv2 = self.addHost("srv2", ip="10.0.0.12/24", mac="00:00:00:00:00:12")
        srv3 = self.addHost("srv3", ip="10.0.0.13/24", mac="00:00:00:00:00:13")

        # Clients
        c1 = self.addHost("c1", ip="10.0.0.21/24", mac="00:00:00:00:00:21")
        c2 = self.addHost("c2", ip="10.0.0.22/24", mac="00:00:00:00:00:22")
        c3 = self.addHost("c3", ip="10.0.0.23/24", mac="00:00:00:00:00:23")
        c4 = self.addHost("c4", ip="10.0.0.24/24", mac="00:00:00:00:00:24")

        # Server links (different capacities to create asymmetry)
        self.addLink(srv1, s1, bw=20, delay="2ms", loss=0)
        self.addLink(srv2, s2, bw=15, delay="5ms", loss=0)
        self.addLink(srv3, s3, bw=25, delay="1ms", loss=0)

        # Client links
        self.addLink(c1, s1, bw=10, delay="3ms")
        self.addLink(c2, s2, bw=10, delay="3ms")
        self.addLink(c3, s3, bw=10, delay="3ms")
        self.addLink(c4, s4, bw=10, delay="2ms")

        # Inter-switch links (mesh-ish so alternate paths exist)
        self.addLink(s1, s4, bw=30, delay="2ms")
        self.addLink(s2, s4, bw=30, delay="2ms")
        self.addLink(s3, s4, bw=30, delay="2ms")
        self.addLink(s1, s2, bw=20, delay="4ms")
        self.addLink(s2, s3, bw=20, delay="4ms")
        self.addLink(s1, s3, bw=15, delay="6ms")


def run(controller_ip="127.0.0.1", controller_port=6633, cli=True):
    setLogLevel("info")
    topo = SmartCDNTopo()
    net = Mininet(
        topo=topo,
        controller=lambda name: RemoteController(name, ip=controller_ip, port=controller_port),
        switch=OVSSwitch,
        link=TCLink,
        autoSetMacs=False,
        autoStaticArp=True
    )
    net.start()
    info("*** Network started\n")
    info("*** Servers: srv1=10.0.0.11, srv2=10.0.0.12, srv3=10.0.0.13\n")
    info("*** Clients: c1..c4\n")
    info("*** Virtual content VIP (controller will redirect): 10.0.0.100:5000\n")

    if cli:
        CLI(net)
    net.stop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--controller-ip", default="127.0.0.1")
    parser.add_argument("--controller-port", type=int, default=6633)
    parser.add_argument("--no-cli", action="store_true")
    args = parser.parse_args()
    run(args.controller_ip, args.controller_port, cli=not args.no_cli)
